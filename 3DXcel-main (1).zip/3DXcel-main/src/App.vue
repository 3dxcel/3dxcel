<script setup>
import { RouterLink, RouterView, useRoute } from "vue-router";
</script>
<template>
  <router-view></router-view>
</template>
<style scoped></style>
