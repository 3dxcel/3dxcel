<script setup>
import AboutPage from "../components/AboutPage.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <AboutPage></AboutPage>
  </main>
</template>
