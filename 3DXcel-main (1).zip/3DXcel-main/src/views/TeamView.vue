<script setup>
import Team from "../components/Team.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <Team></Team>
  </main>
</template>
