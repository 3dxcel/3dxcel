<script setup>
import Beginner from "../components/Beginner.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <Beginner></Beginner>
  </main>
</template>
