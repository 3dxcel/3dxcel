<script setup>
import Intermediate from "../components/Intermediate.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <Intermediate></Intermediate>
  </main>
</template>
