<script setup>
import AllCoursesPage from "../components/AllCoursesPage.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <AllCoursesPage></AllCoursesPage>
  </main>
</template>
