<script setup>
import HomePage from "../components/HomePage.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <HomePage></HomePage>
  </main>
</template>
