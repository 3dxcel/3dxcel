<script setup>
import GetInvolved from "../components/GetInvolved.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <GetInvolved></GetInvolved>
  </main>
</template>
