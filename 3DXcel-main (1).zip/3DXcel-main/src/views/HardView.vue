<script setup>
import Hard from "../components/Hard.vue";
import MenuBar from "../components/MenuBar.vue";
</script>

<template>
  <main>
    <MenuBar></MenuBar>
    <Hard></Hard>
  </main>
</template>
